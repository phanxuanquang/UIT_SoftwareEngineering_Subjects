#include <iostream>
using namespace std;
class fraction {
public:
	int tuSo, mauSo;
public:
	void import() {
		cout << " Tu so la: ";
		cin >> tuSo;
		cout << " Mau so la: ";
		cin >> mauSo;
		while (mauSo == 0)
		{
			cout << "Mau so phai khac 0.\n Mau so moi la: ";
			cin >> mauSo;
		}
	}
};
void UCLN(int& x, int& y);
void main()
{
	fraction a;
	a.import();
	if (a.tuSo == 0) 
	{
		cout << endl << "Phan so sau khi rut gon la 0" << endl;
		system("pause");
	}
	UCLN(a.tuSo, a.mauSo);
	cout << endl << "Phan so sau khi rut gon la: " << a.tuSo << "/" << a.mauSo << endl << endl;
	system("pause");
}
void UCLN(int& x, int& y) {
	for (int i = x; i >= 1; i--)
		if (x % i == 0 && y % i == 0)
		{
			x /= i;
			y /= i;
			break;
		}
}