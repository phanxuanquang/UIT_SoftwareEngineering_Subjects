#include <iostream>
using namespace std;
class fraction {
public:
	int tuSo, mauSo;
public:
	void import() {
		cout << " Tu so la: ";
		cin >> tuSo;
		cout << " Mau so la: ";
		cin >> mauSo;
		while (mauSo == 0)
		{
			cout << "Mau so phai khac 0.\n Mau so moi la: ";
			cin >> mauSo;
		}
	}
	double divide() {
		return double(tuSo) / mauSo;
	}
};
void soSanh(fraction x, fraction y);
void main()
{
	fraction a;
	cout << "Nhap phan so thu nhat: " << endl;
	a.import();
	fraction b;
	cout << "\nNhap phan so thu hai: " << endl;
	b.import();
	soSanh(a, b);
	system("pause");
}
void soSanh(fraction x, fraction y) {
	if (x.divide() > y.divide())
		cout << "\nPhan so lon nhat la: " << x.tuSo << "/" << x.mauSo;
	else if (x.divide() < y.divide())
		cout << "\nPhan so lon nhat la: " << y.tuSo << "/" << y.mauSo;
	else
		cout << "\nHai phan so bang nhau\n";
	cout << endl;
}