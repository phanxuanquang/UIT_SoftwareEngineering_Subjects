#include <iostream>
using namespace std;
class fraction {
public:
	int tuSo, mauSo;
public:
	void import() {
		cout << "Tu so: ";
		cin >> tuSo;
		cout << "Mau so: ";
		cin >> mauSo;
		while (mauSo == 0) {
			cout << "Mau so phai khac 0, nhap lai mau so: ";
			cin >> mauSo;
		}
	}
};
int UCLN(int x, int y);
void tong(fraction x, fraction y);
void hieu(fraction x, fraction y);
void tich(fraction x, fraction y);
void thuong(fraction x, fraction y);
void out(int x, int y);
void main()
{
	fraction a;
	cout << "Nhap phan so thu nhat:" << endl;
	a.import();
	fraction b;
	cout << "Nhap phan so thu hai:" << endl;
	b.import();
	cout << "Tong cua hai phan so la ";
	tong(a, b);
	cout << "Hieu cua hai phan so la ";
	hieu(a, b);
	cout << "Tich cua hai phan so la ";
	tich(a, b);
	cout << "Thuong cua hai phan so la ";
	thuong(a, b);
	system("pause");
}
int UCLN(int x, int y)
{
	if (x * y == 0)
		return 0;
	else for (int i = abs(x); i > 0; i--)
		if (x % i == 0 && y % i == 0)
			return i;
}
void tong(fraction x, fraction y) {
	int tu = x.tuSo * y.mauSo + y.tuSo * x.mauSo;
	int mau = x.mauSo * y.mauSo;
	out(tu, mau);
}
void hieu(fraction x, fraction y) {
	int tu = x.tuSo * y.mauSo - y.tuSo * x.mauSo;
	int mau = x.mauSo * y.mauSo;
	out(tu, mau);
}
void tich(fraction x, fraction y) {
	int tu = x.tuSo * y.tuSo;
	int mau = x.mauSo * y.mauSo;
	out(tu, mau);
}
void thuong(fraction x, fraction y) {
	int tu = x.tuSo * y.mauSo;
	int mau = x.mauSo * y.tuSo;
	if (mau == 0)
		cout << "khong ton tai" << endl;
	else out(tu, mau);
}
void out(int x, int y) {
	if (x == 0)
		cout << 0;
	else {
		int temp = x / UCLN(x, y);
		y /= UCLN(x, y);
		if (y == 1)
			cout << temp;
		else if (y == -1)
			cout << -temp;
		else cout << temp << "/" << y;
	}
	cout << endl;
}