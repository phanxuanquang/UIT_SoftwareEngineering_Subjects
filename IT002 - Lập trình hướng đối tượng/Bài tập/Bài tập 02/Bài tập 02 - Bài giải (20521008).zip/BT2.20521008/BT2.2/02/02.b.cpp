#include <iostream>
#include<string>
using namespace std;
class student {
public:
    string name;
    double math, literature;
    void import() {
        cout << " Ho va ten hoc sinh: ";
        int temp = getchar();
        getline(cin, name);
        cout << " Diem toan: ";
        cin >> math;
        cout << " Diem van: ";
        cin >> literature;
        while (math < 0 || math > 10 || literature > 10 || literature < 0)
        {
            cout << endl << "Diem so khong hop le, hay nhap lai thong tin hoc sinh." << endl;
            import();
        }
    }
};
double average(double math, double literature);
void main()
{
    student hocSinh;
    cout << "Nhap thong tin hoc sinh: " << endl;
    hocSinh.import();
    cout << "Diem trung binh la " << average(hocSinh.math, hocSinh.literature) << endl;
    system("pause");
}
double average(double math, double literature) {
    return (math + literature) / 2;
}