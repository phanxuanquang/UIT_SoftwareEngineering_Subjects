#include <iostream>
#include <string>
using namespace std;
class staff {
public:
    string ID;
    string name;
    string apartment;
    long salaryBasic;
    long bonus;
    long salaryReal = bonus + salaryBasic;
public:
    void import() {
        cout << "Ma nhan vien: ";
        int temp = getchar();
        getline(cin, ID);
        cout << "Ho va ten: ";
        getline(cin, name);
        cout << "Thuoc phong ban: ";
        getline(cin, apartment);
        cout << "Luong co ban: ";
        cin >> salaryBasic;
        cout << "Tien thuong: ";
        cin >> bonus;
        salaryReal = bonus + salaryBasic;
        cout << endl;
    }
};
void sum_salaryReal(int x, staff y[]);
void staff_Amount(int x, staff y[]);
void minSlary_staff(int x, staff y[]);
int main()
{
    staff nhanVien[100]; int n;
    cout << "So nhan vien cua cong ty la: ";
    cin >> n;
    cout << endl;
    for (int i = 0; i < n; i++)
    {
        cout << " Nhan vien thu " << i + 1 << ":" << endl;
        nhanVien[i].import();
    }
    sum_salaryReal(n, nhanVien);
    minSlary_staff(n, nhanVien);
    staff_Amount(n, nhanVien);
    cout << "d. Dai qua em khong biet code sao cho gon. Mong thay thong cam a!" << endl << endl;
    system("pause");
}
void sum_salaryReal(int x, staff y[]) {
    long long temp = 0;
    for (int i = 0; i < x; i++)
        temp += y[i].salaryReal;
    cout << "a. Tong thuc lanh thang cua tat ca nhan vien trong cong ty la: " << temp << endl << endl;
}
void minSlary_staff(int x, staff y[]) {
    long long temp = y[0].salaryBasic;
    for (int i = 1; i < x; i++)
        if (y[i].salaryBasic < temp)
            temp = y[i].salaryBasic;
    cout << "b. Nhung nhan vien co luong co ban thap nhat gom co: " << endl << endl;
    for (int i = 0; i < x; i++)
        for (int j = 1; j < x; j++)
            if (y[i].salaryBasic = y[j].salaryBasic)
                cout << " " << y[i].name << endl;
}
void staff_Amount(int x, staff y[]) {
    int temp = 0;
    for (int i = 0; i < x; i++)
        if (y[i].bonus >= 1200000)
            temp += 1;
    cout << "c. So nhan vien co muc luong thuong tu 1.200.000 tro len la " << temp << endl << endl;
}