#include <iostream>
#include <string>
using namespace std;

class book {
protected:
    string bookName;
    int pageAmount;
    string publisher;
public:
    void import();
    virtual void import_additonInfo() = 0;
    void exportInfo();
    virtual void print() = 0;
};

class textbook : public book {
    string subject;
    double republishTime;
public:
    void import_additonInfo();
    void print();
};
class novel : public book {
    string author;
    int publishYear;
    int copyAmount;
public:
    void import_additonInfo();
    void print();
};
class magazine : public book {
    string genre;
    int rate;
    int publishYear;
public:
    void import_additonInfo();
    void print();
};

void menu();
void importArray(book**, int, int&, int&, int&);
void exportArray(book**, int);

int main() {
    int n, hs, cn, cs;
    hs = cn = cs = 0;
    cout << "So luong sach nhap vao la ";
    cin >> n;
    book** list = new book * [n];
    importArray(list, n, hs, cn, cs);
    exportArray(list, n);
    cout << "So sach giao khoa la " << hs << endl;
    cout << "So tieu thuyet la " << cn << endl;
    cout << "So tap chi la " << cs << endl;
    system("pause");
}

void menu() {
    cout << "------------------" << endl;
    cout << "(1) Sach giao khoa" << endl;
    cout << "(2) Tieu thuyet" << endl;
    cout << "(3) Tap chi" << endl;
    cout << "------------------" << endl;
}
void importArray(book** arr, int size, int& a, int& b, int& c) {
    system("cls");
    book* temp;
    for (int i = 0; i < size; i++) {
        int choice;
        cout << "Cuon sach thu " << i + 1 << ": " << endl;
        menu();
        cout << "Lua chon cua ban la: ";
        cin >> choice;
        switch (choice) {
        case 1:
            temp = new textbook;
            temp->import();
            arr[i] = temp;
            a++;
            break;
        case 2:
            temp = new novel;
            temp->import();
            arr[i] = temp;
            b++;
            break;
        case 3:
            temp = new magazine;
            temp->import();
            arr[i] = temp;
            c++;
            break;
        }
    }
}
void exportArray(book** arr, int size) {
    for (int i = 0; i < size; i++)
        arr[i]->exportInfo();
}

void book::import() {
    char temp;
    temp = getchar();
    cout << "Ten sach: ";
    getline(cin, bookName);
    cout << "So trang: ";
    cin >> pageAmount;
    char temp2;
    temp2 = getchar();
    cout << "Nha xuat ban: ";
    getline(cin, publisher);
    import_additonInfo();
    system("cls");
}
void book::exportInfo() {
    cout << "Ten sach: " << bookName << endl;
    cout << "So trang: " << pageAmount << endl;
    cout << "Nha xuat ban: " << publisher << endl;
    print();
    cout << "==================" << endl;
}

void textbook::import_additonInfo() {
    cout << "Mon hoc: ";
    getline(cin, subject);
    cout << "Tai ban lan thu ";
    cin >> republishTime;
}
void textbook::print() {
    cout << "  Mon hoc: " << subject << endl;
    cout << "  Tai ban lan thu " << republishTime << endl;
}

void novel::import_additonInfo() {
    cout << "Ten tac gia: ";
    getline(cin, author);
    cout << "Nam phat hanh: ";
    cin >> publishYear;
    cout << "So luong an ban: ";
    cin >> copyAmount;
}
void novel::print() {
    cout << "  Ten tac gia: " << author << endl;
    cout << "  Nam phat hanh: " << publishYear << endl;
    cout << "  So luong an ban: " << copyAmount << endl;
}

void magazine::import_additonInfo() {
    cout << "The loai: ";
    getline(cin, genre);
    cout << "Danh cho lua tuoi bat dau tu: ";
    cin >> rate;
    cout << "Nam phat hanh: ";
    cin >> publishYear;
}
void magazine::print() {
    cout << "  The loai: " << genre << endl;
    cout << "  Danh cho lua tuoi bat dau tu: " << rate << endl;
    cout << "  Nam phat hanh: " << publishYear << endl;
}