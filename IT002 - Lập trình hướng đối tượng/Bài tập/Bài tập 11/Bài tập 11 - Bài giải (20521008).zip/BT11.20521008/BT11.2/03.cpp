#include <iostream>
using namespace std;

class point {
    double x, y;
public:
    void set(double, double);
    double get_x();
    double get_y();
    void point_import();
    void point_export();
    point operator+(point);
    void zoom(double);
    void rotate(double);
};

class DaGiac {
protected:
    int pointAmount;
    point* a;
public:
    DaGiac() {
        pointAmount = 0;
        a = NULL;
    }
    void DaGiac_import();
    void DaGiac_export();
    void move_vector();
    void zoom(double ratio);
    void rotate();
};

class TamGiac : public DaGiac {
public:
    TamGiac() {
        pointAmount = 3;
    }
};

class TuGiac : public DaGiac {
public:
    TuGiac() {
        pointAmount = 4;
    }
};
int menuShape();
void menu();
void choice(DaGiac*&);
void zoom(DaGiac&);

int main() {
    DaGiac* a;
    if (menuShape() == 1)
        a = new TamGiac;
    else a = new TuGiac;
    menu();
    choice(a);
    system("pause");
}

int menuShape() {
    system("cls");
    int choice;
    cout << "_______________________________" << endl;
    cout << "1. Tam giac" << endl;
    cout << "2. Tu giac" << endl;
    cout << "_______________________________" << endl;
    cout << "  Lua chon cua ban la ";
    cin >> choice;
    while (choice != 1 && choice != 2)
        menuShape();
    return choice;
}

void menu() {
    cout << "_______________________________" << endl;
    cout << "1. Nhap toa do dinh" << endl;
    cout << "2. Xuat cac toa do dinh" << endl;
    cout << "3. Tinh tien hinh" << endl;
    cout << "4. Phong to hoac thu nho hinh" << endl;
    cout << "5. Xoay hinh theo goc alpha quanh tam O" << endl;
    cout << "_______________________________" << endl;
}
void choice(DaGiac*& a) {
    int x;
    cout << "Nhap lua chon: ";
    cin >> x;
    switch (x) {
    case 1:
        system("cls");
        a->DaGiac_import();
        menu();
        choice(a);
        break;
    case 2:
        system("cls");
        a->DaGiac_export();
        menu();
        choice(a);
        break;
    case 3:
        system("cls");
        a->move_vector();
        menu();
        choice(a);
        break;
    case 4:
        system("cls");
        zoom(*a);
        menu();
        choice(a);
        break;
    case 5:
        system("cls");
        a->rotate();
        menu();
        choice(a);
        break;
    default:
        system("cls");
        cout << "Lua chon khong hop le" << endl;
        menu();
        choice(a);
        break;
    }
}
void zoom(DaGiac& x) {
    double ratio;
    cout << "Chi so phong dai / thu nho: ";
    cin >> ratio;
    while (ratio <= 0) {
        system("cls");
        cout << "Chi so khong hop le" << endl;
        cout << "Chi so phong dai / thu nho moi: ";
        cin >> ratio;
    }
    if (ratio < 1) {
        system("cls");
        cout << "Da thu nho tam giac di " << 1 / ratio << " lan" << endl;
        x.zoom(ratio);
    }
    else if (ratio >= 1) {
        system("cls");
        cout << "Da phong to tam giac len " << ratio << " lan" << endl;
        x.zoom(ratio);
    }
}

double point::get_x() {
    return x;
}
double point::get_y() {
    return y;
}
void point::point_import() {
    cout << "\n Hoanh do: ";
    cin >> x;
    cout << " Tung do: ";
    cin >> y;
}
void point::point_export() {
    cout << "(" << x << "," << y << ") ";
}
void point::set(double x, double y) {
    this->x = x;
    this->y = y;
}
point point::operator+(point move) {
    point temp;
    temp.x = x + move.x;
    temp.y = y + move.y;
    return temp;
}
void point::zoom(double ratio) {
    x *= ratio;
    y *= ratio;
}
void point::rotate(double angle) {
    x = x * cos(angle) + y * sin(angle);
    y = x * sin(angle) + y * cos(angle);
}

void DaGiac::DaGiac_import() {
    a = new point[pointAmount];
    cout << "Nhap toa do dinh cua da giac: " << endl;
    for (int i = 0; i < pointAmount; i++) {
        cout << "Nhap dinh thu " << i + 1 << ": ";
        a[i].point_import();
    }
}
void DaGiac::DaGiac_export() {
    if (a != NULL) {
        cout << "Toa do cac dinh la: " << endl;
        for (int i = 0; i < pointAmount; i++)
            a[i].point_export();
        cout << endl;
    }
    else cout << "Chua co toa do cac dinh" << endl;
}
void DaGiac::move_vector() {
    if (a != NULL) {
        point vector_move;
        cout << "Nhap toa do vector tinh tien:";
        vector_move.point_import();
        system("cls");
        for (int i = 0; i < pointAmount; i++)
            a[i] = a[i] + vector_move;
        cout << "Da tinh tien hinh theo vector (" << vector_move.get_x() << "," << vector_move.get_y() << ")" << endl;
    }
    else cout << "Chua co toa do cac dinh" << endl;
}
void DaGiac::zoom(double ratio) {
    if (a != NULL) {
        for (int i = 0; i < pointAmount; i++)
            a[i].zoom(ratio);
    }
    else {
        system("cls");
        cout << "Chua co toa do cac dinh" << endl;
    }
}
void DaGiac::rotate() {
    if (a != NULL) {
        double angle;
        cout << "Nhap goc quay: ";
        cin >> angle;
        for (int i = 0; i < pointAmount; i++)
            a[i].rotate(angle);
        system("cls");
        cout << "Da quay hinh" << endl;
    }
    else cout << "Chua co toa do cac dinh" << endl;
}