#include <iostream>
#include <string>
using namespace std;

class career {
protected:
    string name;
    int year_of_birth;
    string address;
    string work_place;
public:
    void import();
    virtual void import_additonInfo();
    void exportInfo();
    virtual void print();
};

class student : public career {
    string ID;
    double score;
public:
    student() {
        work_place = "Truong hoc";
    }
    void import_additonInfo();
    void print();
};
class worker : public career {
    long basic_salary;
    int onLeave_day;
    int year_ofExperience;
public:
    worker() {
        work_place = "Nha may";
    }
    void import_additonInfo();
    void print();
};
class singer : public career {
    string line_up;
    int show_amount;
    int album_amount;
public:
    singer() {
        work_place = "San khau";
    }
    void import_additonInfo();
    void print();
};
class doctor : public career {
    string apartment;
    int year_ofWork;
public:
    doctor() {
        work_place = "Benh vien";
    }
    void import_additonInfo();
    void print();
};

void menu();
void importArray(career**, int, int&, int&, int&, int&);
void exportArray(career**, int, int);

int main() {
    int n, hs, cn, cs, bs;
    hs = cn = cs = bs = 0;
    cout << "So phan tu nhap vao la ";
    cin >> n;
    career** list = new career * [n];
    importArray(list, n, hs, cn, cs, bs);
    exportArray(list, n);
    cout << "So hoc sinh la " << hs << endl;
    cout << "So cong nhan la " << cn << endl;
    cout << "So ca si la " << cs << endl;
    cout << "So bac si la " << cs << endl;
    system("pause");
}

void menu() {
    cout << "------------------" << endl;
    cout << "(1) Sinh vien" << endl;
    cout << "(2) Cong nhan" << endl;
    cout << "(3) Ca si" << endl;
    cout << "(4) Bac si" << endl;
    cout << "------------------" << endl;
}
void importArray(career** arr, int size, int &a, int &b, int &c, int&d) {
    system("cls");
    career* temp;
    for (int i = 0; i < size; i++) {
        int choice;
        cout << "Nguoi thu " << i + 1 << ": " << endl;
        menu();
        cout << "Lua chon cua ban la: ";
        cin >> choice;
        switch (choice) {
        case 1:
            temp = new student;
            temp->import();
            arr[i] = temp;
            a++;
            break;
        case 2:
            temp = new worker;
            temp->import();
            arr[i] = temp;
            b++;
            break;
        case 3:
            temp = new singer;
            temp->import();
            arr[i] = temp;
            c++;
            break;
        case 4:
            temp = new doctor;
            temp->import();
            arr[i] = temp;
            d++;
            break;
        }
    }
}
void exportArray(career** arr, int size) {
    for (int i = 0; i < size; i++)
        arr[i]->exportInfo();
}

void career::import() {
    char temp;
    temp = getchar();
    cout << "Ho va ten: ";
    getline(cin, name);
    cout << "Nam sinh: ";
    cin >> year_of_birth;
    char temp2;
    temp2 = getchar();
    cout << "Dia chi: ";
    getline(cin, address);
    import_additonInfo();
    system("cls");
}
void career::import_additonInfo() {
    cout << "Nothing here!";
}
void career::exportInfo() {
    cout << "Ho va ten: " << name << endl;
    cout << "Nam sinh: " << year_of_birth << endl;
    cout << "Dia chi: " << address << endl;
    print();
    cout << "==================" << endl;
}
void career::print() {
    cout << "Nothing here!";
}

void student::import_additonInfo() {
    cout << "Ma sinh vien: ";
    getline(cin, ID);
    cout << "Diem trung binh: ";
    cin >> score;
}
void student::print() {
    cout << "  Noi lam viec: " << work_place << endl;
    cout << "  Ma sinh vien: " << ID << endl;
    cout << "  Diem trung binh: " << score << endl;
}

void worker::import_additonInfo() {
    cout << "Luong co ban: ";
    cin >> basic_salary;
    cout << "So ngay phep: ";
    cin >> onLeave_day;
    cout << "So nam kinh nghiem: ";
    cin >> year_ofExperience;
}
void worker::print() {
    cout << "  Noi lam viec: " << work_place << endl;
    cout << "  Luong co ban: " << basic_salary << endl;
    cout << "  So ngay phep: " << onLeave_day << endl;
    cout << "  So nam kinh nghiem: " << year_ofExperience << endl;
}

void singer::import_additonInfo() {
    cout << "Dong nhac: ";
    cin >> line_up;
    cout << "So show da dien: ";
    cin >> show_amount;
    cout << "So album da ra mat: ";
    cin >> album_amount;
}
void singer::print() {
    cout << "  Noi lam viec: " << work_place << endl;
    cout << "  Dong nhac: " << line_up << endl;
    cout << "  So show da dien: " << show_amount << endl;
    cout << "  So album da ra mat: " << album_amount << endl;
}

void doctor::import_additonInfo() {
    cout << "Khoa chuyen mon: ";
    cin >> apartment;
    cout << "So nam chua benh: ";
    cin >> year_ofWork;
}
void doctor::print() {
    cout << "  Noi lam viec: " << work_place << endl;
    cout << "  Khoa chuyen mon: " << apartment << endl;
    cout << "  So nam chua benh: " << year_ofWork << endl;
}