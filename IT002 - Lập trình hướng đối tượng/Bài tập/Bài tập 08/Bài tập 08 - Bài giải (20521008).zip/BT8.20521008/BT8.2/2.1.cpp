#include <iostream>
#include <string>
using namespace std;

class membership {
    string name;
    int date, month, year;
public:
    virtual void import(){}
    virtual long salary();
    void import_name_Birthday();
    void print();
};

class office : public membership {
    int days_of_work;
public:
    void import();
    long salary();
};

class produce : public membership {
    long basic_salary;
    int product_amount;
public:
    void import();
    long salary();
};

void import_list(membership*[], int);
void export_list(membership*[], int);
void find_Min_Max(membership*[], int);

int main() {
    int n;
    cout << "So nhan vien nhap vao la ";
    cin >> n;
    system("cls");
    membership* staff = new membership[n];
    import_list(&staff, n);
    export_list(&staff, n);
    cout << "----------------------------" << endl;
    find_Min_Max(&staff, n);
    system("pause");
}

void import_list(membership* arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << " NHAN VIEN THU " << i + 1 << ":" << endl;
        cout << "-----------------------" << endl;
        cout << "(1) Nhan vien van phong" << endl;
        cout << "(2) Nhan vien san xuat" << endl;
        cout << "-----------------------" << endl;
        cout << "Lua chon cua ban la: ";
        int type;
        cin >> type;
        while (type != 1 && type != 2) {
            cout << "Khong hop le" << endl;
            cout << "Lua chon cua ban la: ";
            cin >> type;
        }
        if (type == 1)
            arr[i] = new office;
        else arr[i] = new produce;
        arr[i]->import();
    }
}
void export_list(membership *arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << "NHAN VIEN THU " << i + 1 << ": " << endl;
        arr[i]->print();
    }

}
void find_Min_Max(membership *arr[], int size) {
    int index_ofMin = 0, index_ofMax = 0;
    for (int i = 1; i < size; i++) {
        if (arr[i]->salary() < arr[index_ofMin]->salary())
            index_ofMin = i;
        if (arr[i]->salary() > arr[index_ofMax]->salary())
            index_ofMax = i;
    }
    cout << "Thong tin nhan vien co luong cao nhat: " << endl;
    arr[index_ofMax]->print();
    cout << "Thong tin nhan vien co luong thap nhat: " << endl;
    arr[index_ofMin]->print();
}

long membership::salary() {
    return 0;
}
void membership::import_name_Birthday() {
    cin.ignore();
    cout << "Ho va ten: ";
    getline(cin, name);
    cout << "Ngay sinh: ";
    cin >> date;
    cout << "Thang sinh: ";
    cin >> month;
    cout << "Nam sinh: ";
    cin >> year;
}
void membership::print() {
    cout << "  Ho va ten: " << name << endl;
    cout << "  Ngay thang nam sinh: " << date << "." << month << "." << year << endl;
    cout << "  Luong nhan duoc: " << salary() << " (VND) " << endl;
    cout << endl;
}

void office::import() {
    import_name_Birthday();
    cout << "So ngay lam viec la ";
    cin >> days_of_work;
    system("cls");
}
long office::salary() {
    return days_of_work * 100000;
}

void produce::import() {
    import_name_Birthday();
    cout << "Luong co ban la ";
    cin >> basic_salary;
    cout << "So luong san pham la ";
    cin >> product_amount;
    system("cls");
}
long produce::salary() {
    return basic_salary + product_amount * 5000;
}