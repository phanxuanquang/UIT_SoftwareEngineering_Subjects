#include <iostream>
#include <time.h> 
using namespace std;

int random(int, int);

class babylonRobot {
protected:
    int M;
    int S;
    double energyConsuming;
public:
    int type;
    babylonRobot() {
        S = 10;
        type = 0;
    }
    void exportInfo() {
        cout << "S = " << S << ", " << "M = " << M << ", ";
        exportAdd();
        cout << endl;
    }
    virtual void exportAdd() {
        cout << "Nothing Hear";
    }
    double get_energyConsuming() {
        return energyConsuming;
    }
};
class Pedion : public babylonRobot {
protected:
    int F;
public:
    Pedion() {
        M = 20;
        F = random(1, 5);
        energyConsuming = (double)M * S + (F + 1) * S / 2;
        type = 1;
    }
    void exportAdd() {
        cout << "F = " << F << endl;
        cout << "Nang luong tieu thu la " << energyConsuming << endl;
    }
};
class Zattacker : public babylonRobot {
    int P;
public:
    Zattacker() {
        M = 50;
        P = random(20, 30);
        energyConsuming = (double)M * S + P * P * S;
        type = 2;
    }
    void exportAdd() {
        cout << "P = " << P << endl;
        cout << "Nang luong tieu thu la " << energyConsuming << endl;
    }
};
class Carrier : public babylonRobot {
    int E;
public:
    Carrier() {
        M = 30;
        E = random(50, 100);
        energyConsuming = (double)M * S + 4 * E * S;
        type = 3;
    }
    void exportAdd() {
        cout << "E = " << E << endl;
        cout << "Nang luong tieu thu la " << energyConsuming << endl;
    }
};

void importArray(babylonRobot** arr, int size);
void exportType(babylonRobot** arr, int size);
void maxEnergy(babylonRobot** arr, int size, int& total);

int main(){
    int size, totalEnergy;
    cout << "So luong ro-bot la ";
    cin >> size;
    babylonRobot** arr = new babylonRobot * [size];
    importArray(arr, size);
    exportType(arr, size);
    maxEnergy(arr, size, totalEnergy);
    cout << "Tong so nang luong tieu thu cua ca doan robot la " << totalEnergy << endl;
    system("pause");
}

int random(int min, int max) {
    static bool first = true;
    if (first) {
        srand(time(NULL));
        first = false;
    }
    return min + rand() % ((max + 1) - min);
}

void importArray(babylonRobot** arr, int size) {
    babylonRobot* temp;
    int choice;
    for (int i = 0; i < size; i++) {
        cout << "(1) Pedion" << endl;
        cout << "(2) Zattacker" << endl;
        cout << "(3) Carrier" << endl;
        cout << "Ban chon: ";
        cin >> choice;
        switch (choice) {
        case 1:
            temp = new Pedion;
            arr[i] = temp;
            break;
        case 2:
            temp = new Zattacker;
            arr[i] = temp;
            break;
        case 3:
            temp = new Carrier;
            arr[i] = temp;
            break;
        default:
            cout << "Khong hop le" << endl;
            cout << "Ban chon: ";
            cin >> choice;
        }
        system("cls");
    }
}
void exportType(babylonRobot** arr, int size) {
    cout << "\nPEDION ROBOT" << endl;
    for (int i = 0; i < size; i++) {
        if (arr[i]->type == 1)
            arr[i]->exportInfo();
    }
    cout << "=====================" << endl;
    cout << "\nZATTACKER ROBOT" << endl;
    for (int i = 0; i < size; i++) {
        if (arr[i]->type == 2)
            arr[i]->exportInfo();
    }
    cout << "=====================" << endl;
    cout << "\nCARRIER ROBOT" << endl;
    for (int i = 0; i < size; i++) {
        if (arr[i]->type == 3)
            arr[i]->exportInfo();
    }
    cout << "=====================" << endl;
}
void maxEnergy(babylonRobot** arr, int size, int& total) {
    double countP = 0, countZ = 0, countC = 0;
    for (int i = 0; i < size; i++)
        if (arr[i]->type == 1)
            countP += arr[i]->get_energyConsuming();
        else if (arr[i]->type == 2)
            countZ += arr[i]->get_energyConsuming();
        else countC += arr[i]->get_energyConsuming();
    cout << "Robot tieu ton nhieu nang luong nhat la ";
    if (countP > countZ && countP > countC)
        cout << "Pedion" << endl;
    else if (countZ > countP && countZ > countC)
        cout << "Zattacker" << endl;
    else cout << "Carrier" << endl;
    total = countP + countZ + countC;
}