#include <iostream>
#include <string>
using namespace std;

class university {
protected:
    string ID, name, address;
    int credit_amount;
    double score;
public:
    int type = 0;
    void import() {
        char temp = getchar();
        cout << "Ma sinh vien: ";
        getline(cin, ID);
        cout << "Ho va ten: ";
        getline(cin, name);
        cout << "Dia chi: ";
        getline(cin, address);
        cout << "Tong so tin chi: ";
        cin >> credit_amount;
        cout << "Diem trung binh: ";
        cin >> score;
        import_additionInfo();
        system("cls");
    }
    virtual void import_additionInfo() {
        cout << "Nothing here!";
    }
    virtual bool isGraduate() {
        return true;
    }
    string getName() {
        return name;
    }
    double getScore() {
        return score;
    }
};
class caoDang : public university {
    double graduateScore;
public:
    void import_additionInfo() {
        cout << "Diem tot nghiep: ";
        cin >> graduateScore;
    }
    bool isGraduate() {
        if (credit_amount >= 120 && score >= 5 && graduateScore >= 5)
            return true;
        return false;
    }

};
class daiHoc : public university {
    string thesisName;
    double thesisScore;
public:
    void import_additionInfo() {
        char temp = getchar();
        cout << "Ten luan van: ";
        getline(cin, thesisName);
        cout << "Diem luan van: ";
        cin >> thesisScore;
    }
    bool isGraduate() {
        if (credit_amount >= 170 && score >= 5 && thesisScore >= 5)
            return true;
        return false;
    }
};

void importArray(university** arr, int size);
int graduateAmount(university** arr, int size);
string maxScore_caoDang(university** arr, int size);
string maxScore_daiHoc(university** arr, int size);

int main() {
    int n;
    cout << "So luong sinh vien nhap vao la: ";
    cin >> n;
    system("cls");
    university** list = new university * [n];
    importArray(list, n);
    cout << "So sinh vien du dieu kien tot nghiep la " << graduateAmount(list, n) << endl;
    cout << "Sinh vien cao dang co diem trung binh cao nhat la " << maxScore_caoDang(list, n) << endl;
    cout << "Sinh vien dai hoc co diem trung binh cao nhat la " << maxScore_daiHoc(list, n) << endl;
    system("pause");
}

void importArray(university** arr, int size) {
    university* temp;
    for (int i = 0; i < size; i++) {
        int choice;
        cout << "Sinh vien thu " << i + 1 << ":" << endl;
        cout << "  (1) Cao dang" << endl;
        cout << "  (2) Dai hoc" << endl;
        cout << "Ban chon: ";
        cin >> choice;
        if (choice == 1) {
            temp = new caoDang;
            temp->import();
            arr[i] = temp;
            arr[i]->type = 1;
        }
        else {
            temp = new daiHoc;
            temp->import();
            arr[i] = temp;
        }
    }
}
int graduateAmount(university** arr, int size) {
    int count = 0;
    for (int i = 0; i < size; i++)
        if (arr[i]->isGraduate())
            count++;
    return count;
}
string maxScore_caoDang(university** arr, int size) {
    int max = 0;
    for (int i = 0; i < size; i++)
        if (arr[i]->getScore() > arr[max]->getScore() && arr[i]->type == 1)
            max = i;
    return arr[max]->getName();
}
string maxScore_daiHoc(university** arr, int size) {
    int max = 0;
    for (int i = 0; i < size; i++)
        if (arr[i]->getScore() > arr[max]->getScore() && arr[i]->type == 0)
            max = i;
    return arr[max]->getName();
}