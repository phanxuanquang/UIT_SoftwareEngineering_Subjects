#include <iostream>
#include <math.h>
using namespace std;

class point {
    double x, y;
public:
    void set(double, double);
    double get_x();
    double get_y();
    void point_import();
    void point_export();
    void rotate(double);
    point operator+(point);
};
class TamGiac {
    point a, b, c;
public:
    void TamGiac_import();
    void TamGiac_export();
    bool check();
    void move_vector();
    void zoom(double);
    void rotate();
};

void call_menu();
void choice(TamGiac&);
void zoom(TamGiac&);
double distance(point, point);

int main() {
    TamGiac x;
    call_menu();
    choice(x);
    system("pause");
}

void call_menu() {
    cout << "_______________________________" << endl;
    cout << "1. Nhap tam giac" << endl;
    cout << "2. Xuat tam giac" << endl;
    cout << "3. Tinh tien tam giac" << endl;
    cout << "4. Phong to hoac thu nho tam giac" << endl;
    cout << "5. Xoay tam giac theo goc alpha quanh tam O" << endl;
    cout << "_______________________________" << endl;
}
void choice(TamGiac& a) {
    int x;
    cout << "Nhap lua chon: ";
    cin >> x;
    switch (x) {
    case 1:
        system("cls");
        a.TamGiac_import();
        call_menu();
        choice(a);
        break;
    case 2:
        system("cls");
        a.TamGiac_export();
        call_menu();
        choice(a);
        break;
    case 3:
        system("cls");
        a.move_vector();
        call_menu();
        choice(a);
        break;
    case 4:
        system("cls");
        zoom(a);
        call_menu();
        choice(a);
        break;
    case 5:
        system("cls");
        a.rotate();
        call_menu();
        choice(a);
        break;
    default:
        system("cls");
        cout << "Lua chon khong ton tai" << endl;
        call_menu();
        choice(a);
        break;
    }
}
void zoom(TamGiac& x) {
    double ratio;
    cout << "Chi so phong dai / thu nho: ";
    cin >> ratio;
    while (ratio <= 0) {
        system("cls");
        cout << "Chi so khong hop le" << endl;
        cout << "Chi so phong dai / thu nho moi: ";
        cin >> ratio;
    }
    if (ratio < 1) {
        system("cls");
        cout << "Da thu nho tam giac di " << 1 / ratio << " lan" << endl;
        x.zoom(ratio);
    }
    else if (ratio >= 1) {
        system("cls");
        cout << "Da phong to tam giac len " << ratio << " lan" << endl;
        x.zoom(ratio);
    }
}
double distance(point a, point b) {
    double x = a.get_x() - b.get_x();
    double y = a.get_y() - b.get_y();
    return sqrt(x*x+y*y);
}

double point::get_x() {
    return x;
}
double point::get_y() {
    return y;
}
void point::point_import() {
    cout << "\n Hoanh do: ";
    cin >> x;
    cout << " Tung do: ";
    cin >> y;
}
void point::point_export() {
    cout << "(" << x << "," << y << ")" << endl;
}
void point::set(double x, double y) {
    this->x = x;
    this->y = y;
}
void point::rotate(double angle){
    x = x * cos(angle) + y * sin(angle);
    y = x * sin(angle) + y * cos(angle);
}
point point::operator+(point move) {
    point temp;
    temp.x = x + move.x;
    temp.y = y + move.y;
    return temp;
}

void TamGiac::TamGiac_import() {
    cout << "Nhap toa do ba dinh cua tam giac: " << endl;
    cout << "  Dinh thu nhat: ";
    a.point_import();
    cout << "  Dinh thu hai: ";
    b.point_import();
    cout << "  Dinh thu ba: ";
    c.point_import();
    while (!check()) {
        system("cls");
        cout << "Day khong phai toa do ba dinh cua mot tam giac, hay nhap lai" << endl << endl;
        TamGiac_import();
    }
}
void TamGiac::TamGiac_export() {
    cout << "Toa do ba dinh cua tam giac la: " << endl;
    cout << "  Dinh thu nhat: ";
    a.point_export();
    cout << "  Dinh thu hai: ";
    b.point_export();
    cout << "  Dinh thu ba: ";
    c.point_export();
}
void TamGiac::move_vector() {
    point vector_move;
    cout << "Nhap toa do vector tinh tien:";
    vector_move.point_import();
    system("cls");
    a = a + vector_move;
    b = b + vector_move;
    c = c + vector_move;
    cout << "Da tinh tien tam giac theo vector (" << vector_move.get_x() << "," << vector_move.get_y() << ")" << endl;
}
void TamGiac::rotate(){
    double angle;
    cout << "Nhap goc quay: ";
    cin >> angle;
    a.rotate(angle);
    b.rotate(angle);
    c.rotate(angle);
    system("cls");
    cout << "Da quay tam giac" << endl;
}
void TamGiac::zoom(double ratio) {
    a.set(a.get_x() * ratio, a.get_y() * ratio);
    b.set(b.get_x() * ratio, b.get_y() * ratio);
    c.set(c.get_x() * ratio, c.get_y() * ratio);
}
bool TamGiac::check() {
    double x = distance(a, b);
    double y = distance(b, c);
    double z = distance(a, c);
    if (x + y > z && y + z > x && x + z > y)
        return true;
    return false;
}