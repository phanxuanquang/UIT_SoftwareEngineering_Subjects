﻿#include <iostream>
using namespace std;

class Matrix;
class Vector{
private:
    double* coords;
    int n;
public:
    Vector();
    Vector(int N, double x);
    Vector(const Vector& a);
    ~Vector();
    void Nhap();
    void Xuat();
    int Cong(const Vector& a);
    void NhanK(const double& k);
    int Tru(Vector a);
    double TichVoHuong(const Vector& a);
    friend Vector multiply(const Matrix& a, const Vector& b);
};

class Matrix{
private:
    int m;
    int n;
    double** elements;
public:
    Matrix();
    ~Matrix();
    Matrix(const Matrix& a);
    void Nhap();
    void Xuat();
    int Cong(const Matrix& a);
    void Nhan(const double& k);
    int Nhan(const Matrix& a);
    friend Vector multiply(const Matrix& a, const Vector& b);
};

int main() {
    Matrix matrix;
    Vector vector;
    matrix.Nhap();
    vector.Nhap();
    Vector result = multiply(matrix, vector);
    result.Xuat();
    system("pause");
}

Vector::Vector() {
    coords = NULL;
}
Vector::Vector(int N, double x) {
    n = N;
    coords = new double[n];
    for (int i = 0; i < n; i++)
        coords[i] = x;
}
Vector::Vector(const Vector& a) {
    n = a.n;
    coords = new double[n];
    for (int i = 0; i < n; i++)
        coords[i] = a.coords[i];
}
Vector::~Vector() {
    if (coords != NULL) {
        delete coords;
        coords = NULL;
    }
}
void Vector::Nhap() {
    system("cls");
    cout << "So chieu cua vector la ";
    cin >> n;
    cout << "Nhap cac toa do cua vector: " << endl;
    coords = new double[n];
    for (int i = 0; i < n; i++)
        cin >> coords[i];
}
void Vector::Xuat() {
    system("cls");
    cout << "Vector ket qua co toa do la: ";
    for (int i = 0; i < n; i++)
        cout << roundf(coords[i] * 100) / 100 << " ";
    cout << endl;
}
int Vector::Cong(const Vector& a) {
    if (n == a.n) {
        for (int i = 0; i < n; i++)
            coords[i] += a.coords[i];
        return 1;
    }
    return 0;
}
void Vector::NhanK(const double& k) {
    for (int i = 0; i < n; i++)
        coords[i] *= k;
}
int Vector::Tru(Vector a) {
    if (n == a.n) {
        a.NhanK(-1);
        Cong(a);
        return 1;
    }
    return 0;
}
double Vector::TichVoHuong(const Vector& a) {
    double scalar = 0;
    for (int i = 0; i < n; i++)
        scalar += coords[i] * a.coords[i];
    return scalar;
}

Matrix::Matrix() {
    m = n = 0;
    elements = NULL;
}
Matrix::~Matrix() {
    if (elements != NULL) {
        for (int i = 0; i < m; i++) {
            delete elements[i];
            elements[i] = NULL;
        }
        delete elements;
        elements = NULL;
    }
    else return;
}
Matrix::Matrix(const Matrix& a) {
    m = a.m;
    n = a.n;
    elements = new double* [m];
    for (int i = 0; i < m; i++)
        elements[i] = new double[n];
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            elements[i][j] = a.elements[i][j];
}
void Matrix::Nhap() {
    cout << "So hang la ";
    cin >> m;
    cout << "So cot la ";
    cin >> n;
    system("cls");
    cout << "Nhap ma tran" << endl;
    elements = new double* [m]; 
    for (int i = 0; i < m; i++)
        elements[i] = new double[n]; 
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            cin >> elements[i][j];
}
void Matrix::Xuat() {
    cout << "Ma tran la " << endl;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++)
            cout << elements[i][j] << " ";
        cout << endl;
    }
}
int Matrix::Cong(const Matrix& a) {
    if (n != a.n || m != a.m)
        return 0;
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            elements[i][j] += a.elements[i][j];
    return 1;
}
void Matrix::Nhan(const double& k) {
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            elements[i][j] *= k;
}
int Matrix::Nhan(const Matrix& a) {
    if (n != a.m)
        return 0;
    double** temp = new double* [m];
    for (int i = 0; i < m; i++)
        temp[i] = new double[a.n];
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < a.n; j++) {
            temp[i][j] = 0;
            for (int k = 0; k < n; k++)
                temp[i][j] += elements[i][k] * a.elements[k][j];
        }
    }
    for (int i = 0; i < m; i++)
        delete elements[i];
    delete elements;
    m = m;
    n = a.n;
    elements = temp;
    return 1;
}

Vector multiply(const Matrix& a, const Vector& b) {
    if (a.n != b.n) {
        cout << "Khong the nhan duoc!" << endl;
        return Vector(0, 0);
    }
    Vector result(a.m, 0);
    result.n = a.m;
    for (int i = 0; i < a.m; i++) {
        result.coords[i] = 0;
        for (int j = 0; j < b.n; j++)
            result.coords[i] += b.coords[j] * a.elements[i][j];
    }
    return result;
}