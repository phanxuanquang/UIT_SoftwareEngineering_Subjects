#include <iostream>
using namespace std;

class ThoiGian {
    int hour, minute, second;

public:
    ThoiGian();
    ThoiGian(int x, int y, int z);

    bool isHour();
    bool isMinuteSecond();

    friend istream& operator>>(istream& input, ThoiGian& T);
    friend  ostream& operator<<(ostream& output, ThoiGian& T);

    ThoiGian operator+(ThoiGian x);
    ThoiGian operator-(ThoiGian x);
    ThoiGian operator++(int x);
    ThoiGian operator--(int x);

    bool operator>(ThoiGian x);
    bool operator<(ThoiGian x);
    bool operator==(ThoiGian x);
};

int main(){
    ThoiGian a, b;
    cout << "  THOI GIAN THU NHAT: " << endl;
    cin >> a;
    system("cls");
    cout << "  THOI GIAN THU HAI: " << endl;
    cin >> b;
    system("cls");
    cout << "Thoi gian thu nhat la " << a << endl;
    cout << "Thoi gian thu hai la " << b << endl;
    cout << endl;
    ThoiGian total = a + b;
    cout << "Tong hai thoi gian la ";
    cout << total << endl;
    ThoiGian subtract = a - b;
    if (!subtract.isHour())
        cout << "Khong the tru" << endl;
    else cout << "Hieu hai thoi gian la " << subtract << endl;
    if (a > b)
        cout << a << " > " << b << endl;
    else if (a < b)
        cout << a << " < " << b << endl;
    else if (a == b)
        cout << a << " = " << b << endl;
    cout << endl;
    cout << a << " + 1 giay" << " = ";
    a++;
    cout << a << endl;
    ThoiGian tempSubtract = b--;
    if (!tempSubtract.isHour())
        cout << "Khong the tru di 1 giay" << endl;
    else cout << b << " - 1 giay" << " = " << tempSubtract << endl;
    cout << endl;
    system("pause");
}

ThoiGian::ThoiGian() {
    hour = minute = second = 0;
}
ThoiGian::ThoiGian(int x, int y, int z) {
    hour = x;
    minute = y;
    second = z;
}

bool ThoiGian::isHour() {
    if (hour < 0)
        return false;
    return true;
}
bool ThoiGian::isMinuteSecond() {
    if (second < 0 || second>59 || minute < 0 || minute>59)
        return false;
    return true;
}

istream& operator>>(istream& input, ThoiGian& T) {
    cout << "Gio: ";
    input >> T.hour;
    while (!T.isHour()) {
        cout << "  Khong hop le. Gio moi la: ";
        input >> T.hour;
    }
    cout << "Phut: ";
    input >> T.minute;
    while (!T.isMinuteSecond()) {
        cout << "  Khong hop le. Phut moi la: ";
        input >> T.minute;
    }
    cout << "Giay: ";
    input >> T.second;
    while (!T.isMinuteSecond()) {
        cout << "  Khong hop le. Giay moi la: ";
        input >> T.second;
    }
    return input;
}
ostream& operator<<(ostream& output, ThoiGian& T) {
    output << T.hour << ":" << T.minute << ":" << T.second;
    return output;
}
ThoiGian ThoiGian::operator+(ThoiGian x) {
    ThoiGian result;
    result.second = second + x.second;
    result.minute = minute + x.minute;
    result.hour = hour + x.hour;
    if (!result.isMinuteSecond()) {
        result.second -= 60;
        result.minute++;
    }
    if (!result.isMinuteSecond()) {
        result.minute -= 60;
        result.hour++;
    }
    return result;
}
ThoiGian ThoiGian::operator-(ThoiGian x) {
    ThoiGian result;
    result.second = second - x.second;
    result.minute = minute - x.minute;
    result.hour = hour - x.hour;
    if (!result.isMinuteSecond()) {
        result.second += 60;
        result.minute--;
    }
    if (!result.isMinuteSecond()) {
        result.minute += 60;
        result.hour--;
    }
    return result;
}
ThoiGian ThoiGian::operator++(int x) {
    ThoiGian result;
    result.second = second + 1;
    result.minute = minute;
    result.hour = hour;
    if (!result.isMinuteSecond()) {
        result.second -= 60;
        result.minute++;
    }
    if (!result.isMinuteSecond()) {
        result.minute -= 60;
        result.hour++;
    }
    return result;
}
ThoiGian ThoiGian::operator--(int x) {
    ThoiGian result;
    result.second = second - 1;
    result.minute = minute;
    result.hour = hour;
    if (!result.isMinuteSecond()) {
        result.second += 60;
        result.minute--;
    }
    if (!result.isMinuteSecond()) {
        result.minute += 60;
        result.hour--;
    }
    return result;
}
bool ThoiGian::operator>(ThoiGian x) {
    if (hour > x.hour)
        return true;
    else if (hour == x.hour && minute > x.minute)
        return true;
    else if (hour == x.hour && minute == x.minute && second > x.second)
        return true;
    return false;
}
bool ThoiGian::operator<(ThoiGian x) {
    if (hour > x.hour)
        return true;
    else if (hour == x.hour && minute < x.minute)
        return true;
    else if (hour == x.hour && minute == x.minute && second < x.second)
        return true;
    return false;
}
bool ThoiGian::operator==(ThoiGian x) {
    if (hour == x.hour && minute == x.minute && second == x.second)
        return true;
    return false;
}
