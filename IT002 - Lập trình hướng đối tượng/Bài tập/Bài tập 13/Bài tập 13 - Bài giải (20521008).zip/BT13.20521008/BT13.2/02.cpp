#include <iostream>
using namespace std;

class DaThuc {
    int size;
    double* arr;
public:
    DaThuc();
    DaThuc(int);

    int getSize();
    int valueOf(double);

    friend istream& operator>>(istream& input, DaThuc& T);
    friend ostream& operator<<(ostream& output, const  DaThuc& T);

    DaThuc operator+(DaThuc);
    DaThuc operator-(DaThuc);
    double& operator[](int);
};

void calculate(DaThuc, DaThuc);

int main() {
    DaThuc a, b;
    cout << "DA THUC THU NHAT:" << endl;
    cin >> a;
    cout << "DA THUC THU HAI:" << endl;
    cin >> b;
    cout << "Da thuc thu nhat la: " << a << endl;
    cout << "Da thuc thu hai la: " << b << endl;
    cout << endl;
    DaThuc total = a + b;
    cout << "Tong cua hai da thuc la: " << total << endl;
    DaThuc subtract = a - b;
    cout << "Hieu cua hai da thuc la: " << subtract << endl;
    system("pause");
    calculate(a, b);
    cout << endl;
    cout << "Gia tri tai bac cao nhat cua f1(x) la " << a[a.getSize()] << "*x^" << a.getSize() << endl;
    cout << "Gia tri tai bac cao nhat cua f2(x) la " << b[b.getSize()] << "*x^" << b.getSize() << endl;
    system("pause");
}

DaThuc::DaThuc() {
    size = 0;
    arr = new double[size + 1];
    arr[0] = 0;
}
DaThuc::DaThuc(int level) {
    size = level;
    arr = new double[size + 1];
    for (int i = 0; i <= level; i++)
        arr[i] = 0;
}

istream& operator>>(istream& input, DaThuc& T) {
    cout << "Bac cua da thuc: ";
    input >> T.size;
    T.arr = new double[T.size + 1];
    for (int i = 0; i <= T.size; i++) {
        cout << "  He so bac " << i << " la: ";
        input >> T.arr[i];
    }
    system("cls");
    return input;
}
ostream& operator<<(ostream& output, const DaThuc& T) {
    output << T.arr[0] << " + " << T.arr[1] << "*x";
    for (int i = 2; i <= T.size; i++)
        if (T.arr[i] != 0)
            output << " + " << T.arr[i] << "*x^" << i;
    return output;
}

int DaThuc::getSize() {
    return size;
}
int DaThuc::valueOf(double x) {
    int total = 0;
    for (int i = 0; i < size; i++)
        total += pow(x, i) * arr[i];
    return total;
}

DaThuc DaThuc::operator+(DaThuc a) {
    int somu = max(this->size, a.size);
    int temp = min(this->size, a.size);
    bool flag = this->size > a.size;
    double* arr = new double[somu + 1];
    for (int i = 0; i <= temp; i++) {
        *(arr + i) = (*this)[i] + a[i];
    }
    if (flag) {
        for (int i = temp + 1; i <= this->size; i++) {
            *(arr + i) = (*this)[i];
        }
    }
    else {
        for (int i = temp + 1; i <= a.size; i++) {
            *(arr + i) = a[i];
        }
    }
    DaThuc result;
    result.size = somu;
    result.arr = arr;
    return result;
}
DaThuc DaThuc::operator-(DaThuc a) {
    int somu = max(this->size, a.size);
    int temp = min(this->size, a.size);
    bool flag = this->size > a.size;
    double* arr = new double[somu + 1];
    for (int i = 0; i <= temp; i++) {
        *(arr + i) = (*this)[i] - a[i];
    }
    if (flag) {
        for (int i = temp + 1; i <= this->size; i++) {
            *(arr + i) = (*this)[i];
        }
    }
    else {
        for (int i = temp + 1; i <= a[i]; i++) {
            *(arr + i) = -a[i];
        }
    }
    DaThuc result;
    result.size = somu;
    result.arr = arr;
    return result;
}
double& DaThuc::operator[](int level) {
    return arr[level];
}

void calculate(DaThuc a, DaThuc b) {
    system("cls");
    double x;
    cout << " x = ";
    cin >> x;
    cout << "f1(" << x << ") = " << a.valueOf(x) << endl;
    cout << "f2(" << x << ") = " << b.valueOf(x) << endl;
}
