#include <iostream>
#include <math.h>
using namespace std;

class point {
    double x, y;
public:
    point() {
        this->x = 0;
        this->y = 0;
    }
    point(double x, double y) {
        this->x = x;
        this->y = y;
    }
    double get_x();
    double get_y();
    void point_import();
    void point_export();
    point operator+(point);
    double distance_to(point);
};
class triangle {
    point a, b, c;
public:
    triangle() {
    }
    triangle(point a, point b, point c) {
        this->a = a;
        this->b = b;
        this->c = c;
    }
    void triangle_import();
    void triangle_export();
    bool istriangle();
    void move(point);
    double perimeter();
    double area();
};

void triangle_array_Import(triangle[], int);
void triangle_array_Export(triangle[], int);
void findMax_Perimeter_Area(triangle[], int);
void move(triangle[], int);

void call_menu();
void choice(triangle[], int);

int main() {
    int n;
    cout << "So tam giac nhap vao la ";
    cin >> n;
    triangle* t = new triangle[n];
    call_menu();
    choice(t, n);
    system("pause");
}

void triangle_array_Import(triangle arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << "Tam giac thu " << i + 1 << ":" << endl;
        arr[i].triangle_import();
        system("cls");
    }
}
void triangle_array_Export(triangle arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << "Tam giac thu " << i + 1 << ":" << endl;
        arr[i].triangle_export();
    }
}
void findMax_Perimeter_Area(triangle arr[], int size) {
    int maxPerimeter_Index = 0;
    int maxArea_Index = 0;
    for (int i = 0; i < size; i++) {
        if (arr[i].perimeter() > arr[maxPerimeter_Index].perimeter())
            maxPerimeter_Index = i;
        if (arr[i].perimeter() > arr[maxArea_Index].perimeter())
            maxArea_Index = i;
    }
    if (maxPerimeter_Index == maxArea_Index) {
        cout << "Tam giac co chu vi lon nhat va dien tich lon nhat co toa do ba dinh la: " << endl;
        arr[maxPerimeter_Index].triangle_export();
    }
    else {
        cout << "Tam giac co chu vi lon nhat co toa do ba dinh la: " << endl;
        arr[maxPerimeter_Index].triangle_export();
        cout << "Tam giac co dien tich lon nhat co toa do ba dinh la: " << endl;
        arr[maxArea_Index].triangle_export();
    }
}
void move(triangle arr[], int size) {
    point vector;
    cout << "Nhap toa do vector tinh tien:";
    vector.point_import();
    system("cls");
    for (int i = 0; i < size; i++)
        arr[i].move(vector);
    cout << "Cac tam giac sau khi tinh tien co toa do:" << endl;
    triangle_array_Export(arr, size);
}
void call_menu() {
    cout << "_______________________________" << endl;
    cout << "1. Nhap vao n tam giac" << endl;
    cout << "2. Xuat ra n tam giac" << endl;
    cout << "3. Xuat ra tam giac co chu vi lon nhat va tam giac co dien tich lon nhat" << endl;
    cout << "4. Tinh tien tat ca tam giac theo vector V" << endl;
    cout << "_______________________________" << endl;
}
void choice(triangle a[], int size) {
    int x;
    cout << "Nhap lua chon: ";
    cin >> x;
    switch (x) {
    case 1:
        system("cls");
        triangle_array_Import(a, size);
        call_menu();
        choice(a, size);
        break;
    case 2:
        system("cls");
        triangle_array_Export(a, size);
        call_menu();
        choice(a, size);
        break;
    case 3:
        system("cls");
        findMax_Perimeter_Area(a, size);
        call_menu();
        choice(a, size);
        break;
    case 4:
        system("cls");
        move(a, size);
        call_menu();
        choice(a, size);
        break;
    default:
        system("cls");
        cout << "Lua chon khong ton tai" << endl;
        call_menu();
        choice(a, size);
        break;
    }
}

double point::get_x() {
    return x;
}
double point::get_y() {
    return y;
}
void point::point_import() {
    cout << "\n Hoanh do: ";
    cin >> x;
    cout << " Tung do: ";
    cin >> y;
}
void point::point_export() {
    cout << "(" << x << "," << y << ")" << endl;
}
point point::operator+(point move) {
    point temp;
    temp.x = x + move.x;
    temp.y = y + move.y;
    return temp;
}
double point::distance_to(point a) {
    double m = a.get_x() - x;
    double n = a.get_y() - y;
    return sqrt(m * m + n * n);
}

void triangle::triangle_import() {
    cout << "Nhap toa do ba dinh cua tam giac: " << endl;
    cout << "  Dinh thu nhat: ";
    a.point_import();
    cout << "  Dinh thu hai: ";
    b.point_import();
    cout << "  Dinh thu ba: ";
    c.point_import();
    if (!istriangle()) {
        system("cls");
        cout << "Day khong phai toa do ba dinh cua mot tam giac, hay nhap lai" << endl << endl;
        triangle_import();
    }
}
void triangle::triangle_export() {
    cout << "  Dinh thu nhat: ";
    a.point_export();
    cout << "  Dinh thu hai: ";
    b.point_export();
    cout << "  Dinh thu ba: ";
    c.point_export();
}
void triangle::move(point vector) {
    a = a + vector;
    b = b + vector;
    c = c + vector;
}
bool triangle::istriangle() {
    double x = a.distance_to(b);
    double y = b.distance_to(c);
    double z = c.distance_to(a);
    if (x + y > z && y + z > x && x + z > y)
        return true;
    return false;
}
double triangle::perimeter() {
    double x = a.distance_to(b);
    double y = b.distance_to(c);
    double z = c.distance_to(a);
    return x + y + z;
}
double triangle::area() {
    double x = a.distance_to(b);
    double y = b.distance_to(c);
    double z = c.distance_to(a);
    double p = (x + y + z) / 2;
    return sqrt(p * (p - x) * (p - y) * (p - z));
}