#include <iostream>
#include <math.h>
using namespace std;

class point {
    double x, y;
public:
    point() {
        this->x = 0;
        this->y = 0;
    }
    point(double x, double y) {
        this->x = x;
        this->y = y;
    }

    void import();
    void import_ForVector();
    void print();
    point operator+(point);
    double distance_to(point);
};

void point_import(point[], int);
void point_export(point[], int);
void find_Max(point[], int);
void find_Min(point[], int);
void move(point[], int);

void call_menu(int);
void choose(point[], int&);

int main(){
    int n;
    cout << "So diem nhap vao la: ";
    cin >> n;
    point* p = new point[n];
    call_menu(n);
    choose(p, n);
}

void point::import() {
    cout << "   Nhap gia tri: Nhap 'Y' - Chon gia tri mac dinh: Nhap 'N'" << endl;
    cout << "   Cau tra loi cua ban la: ";
    string answer;
    cin >> answer;
    system("cls");
    if (answer == "n" || answer == "N") {
        point();
        cout << "Da chon gia tri mac dinh la (0,0)" << endl;
        return;
    }
    else if (answer == "y" || answer == "y") {
        cout << "Hoanh do: ";
        cin >> x;
        cout << "Tung do: ";
        cin >> y;
        system("cls");
    }
    else {
        cout << "Lua chon khong hop le, hay nhap lai cau tra loi" << endl;
        import();
    }
}
void point::import_ForVector() {
    cout << " Hoanh do: ";
    cin >> x;
    cout << " Tung do: ";
    cin >> y;
}
void point::print() {
    cout << "(" << x << "," << y << ") ";
}
point point::operator+(point move) {
    point temp;
    temp.x = x + move.x;
    temp.y = y + move.y;
    return temp;
}
double point::distance_to(point a) {
    double temp1 = a.x - x;
    double temp2 = a.y - y;
    return sqrt((temp1 * temp1 + temp2 * temp2));
}

void point_import(point arr[], int size) {
    system("cls");
    for (int i = 0; i < size; i++) {
        cout << "Diem thu " << i + 1 << ":" << endl;
        arr[i].import();
    }
}
void point_export(point arr[], int size) {
    cout << "Toa do cac diem nhap vao la: " << endl;
    for (int i = 0; i < size; i++) {
        cout << " Diem thu " << i + 1 << " la ";
        arr[i].print();
        cout << endl;
    }
}
void find_Max(point arr[], int size) {
    double max = 0;
    for (int i = 0; i < size - 1; i++)
        for (int j = i + 1; j < size; j++)
            if (arr[i].distance_to(arr[j]) > max)
                max = arr[i].distance_to(arr[j]);
    cout << "Khoang cach lon nhat giua hai diem trong tap diem la " << max << endl;
}
void find_Min(point arr[], int size) {
    double min = arr[0].distance_to(arr[1]);
    for (int i = 0; i < size - 1; i++)
        for (int j = i + 1; j < size; j++)
            if (arr[i].distance_to(arr[j]) < min)
                min = arr[i].distance_to(arr[j]);
    cout << "Khoang cach nho nhat giua hai diem trong tap diem la " << min << endl;
}
void move(point arr[], int size) {
    system("cls");
    cout << "Nhap vector tinh tien:" << endl;
    point vector;
    vector.import_ForVector();
    for (int i = 0; i < size; i++)
        arr[i] = arr[i] + vector;
    system("cls");
    cout << "Toa do cac diem sau khi tinh tien la: ";
    for (int i = 0; i < size; i++)
        arr[i].print();
    cout << endl;
}

void call_menu(int size) {
    cout << "__________________________________________________" << endl;
    cout << "1. Nhap vao " << size << " diem" << endl;
    cout << "2. Xuat ra " << size << " diem vua nhap" << endl;
    cout << "3. Tim khoang cach lon nhat va khoang cach nho nhat trong tap diem" << endl;
    cout << "4. Tinh tien tat ca cac diem theo vector V" << endl;
    cout << "__________________________________________________" << endl;
}
void choose(point arr[], int& size) {
    cout << "Lua chon cua ban la: ";
    int choice;
    cin >> choice;
    switch (choice) {
    case 1:
        point_import(arr, size);
        call_menu(size);
        choose(arr, size);
        break;
    case 2:
        system("cls");
        point_export(arr, size);
        call_menu(size);
        choose(arr, size);
        break;
    case 3:
        system("cls");
        find_Max(arr, size);
        find_Min(arr, size);
        call_menu(size);
        choose(arr, size);
        break;
    case 4:
        move(arr, size);
        call_menu(size);
        choose(arr, size);
        break;
    default:
        system("cls");
        cout << "Lua chon khong hop le, hay nhap lai" << endl;
        call_menu(size);
        choose(arr, size);
        break;
    }
}