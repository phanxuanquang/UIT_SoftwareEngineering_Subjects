Đặt tệp Cow.wav, Goat.wav và Sheep.wav vào cùng thư mục với tệp mã nguồn

1 - Trong Visual Studio, nhấp chuột phải vào project đang mở và chọn "Properties".
2 - Đi theo đường dẫn Configuration Properties đến Linker và Input
3 - Bên phải mục "Additional Dependencies", nhấp vào <Edit...> và điền "winmm.lib" vào
4 - Chọn "Ok" và đợi 15 giây

