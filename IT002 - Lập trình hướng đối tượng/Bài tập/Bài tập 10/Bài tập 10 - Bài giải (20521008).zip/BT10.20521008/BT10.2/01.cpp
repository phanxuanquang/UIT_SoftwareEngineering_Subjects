#include <iostream>
#include <string>
using namespace std;

class membership {
    string name;
    int date, month, year;
public:
    virtual void import(){}
};

class office : public membership {
public:
    int count = 0;
    void import();
};

class produce : public membership {
public:
    int count = 0;
    void import();
};

void import_list(membership**, int);
void find_Min_Max();

int main() {
    int n;
    cout << "So nhan vien nhap vao la ";
    cin >> n;
    system("cls");
    membership* staff = new membership[n];
    import_list(&staff, n);
    cout << "----------------------------" << endl;
    find_Min_Max();
    system("pause");
}

void import_list(membership** arr, int size) {
    for (int i = 0; i < size; i++) {
        cout << " NHAN VIEN THU " << i + 1 << ":" << endl;
        cout << "-----------------------" << endl;
        cout << "(1) Nhan vien van phong" << endl;
        cout << "(2) Nhan vien san xuat" << endl;
        cout << "-----------------------" << endl;
        cout << "Lua chon cua ban la: ";
        int type;
        cin >> type;
        while (type != 1 && type != 2) {
            cout << "Khong hop le" << endl;
            cout << "Lua chon cua ban la: ";
            cin >> type;
        }
        if (type == 1)
            arr[i] = new office;
        else arr[i] = new produce;
        arr[i]->import();
    }
}
void find_Min_Max() {
    office a;
    produce b;
    cout << "a = " << a.count << endl;
    cout << "b = " << b.count << endl;
}

void office::import() {
    int temp;
    cin >> temp;
    system("cls");
    count++;
}

void produce::import() {
    int temp;
    cin >> temp;
    system("cls");
    count++;
}