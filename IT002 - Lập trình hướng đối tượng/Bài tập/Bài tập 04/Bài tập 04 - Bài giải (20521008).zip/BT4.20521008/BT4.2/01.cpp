#include <iostream>
using namespace std;
class fraction {
	int tuSo, mauSo;
public:
	void import();
	void simplify();
	void print();
	fraction operator+(fraction);
	fraction operator-(fraction);
	fraction operator*(fraction);
	fraction operator/(fraction);
};
void total(fraction, fraction);
void subtract(fraction, fraction);
void multiply(fraction, fraction);
void divide(fraction, fraction);
void print(fraction&);
void main()
{
	fraction a, b;
	cout << "Nhap phan so thu nhat" << endl;
	a.import();
	cout << "Nhap phan so thu hai" << endl;
	b.import();
	total(a, b);
	subtract(a, b);
	multiply(a, b);
	divide(a, b);
	system("pause");
}
void total(fraction x, fraction y) {
	cout << " Tong cua hai phan so la ";
	fraction sum = x + y;
	print(sum);
}
void subtract(fraction x, fraction y) {
	cout << " Hieu cua hai phan so la ";
	fraction sub = x - y;
	print(sub);
}
void multiply(fraction x, fraction y) {
	cout << " Tich cua hai phan so la ";
	fraction mul = x * y;
	print(mul);
}
void divide(fraction x, fraction y) {
	cout << " Thuong cua hai phan so la ";
	fraction div = x / y;
	print(div);
}
void print(fraction &x) {
	x.simplify();
	x.print();
	cout << endl;
}
void fraction::import() {
	cout << " Tu so la: ";
	cin >> tuSo;
	cout << " Mau so la: ";
	cin >> mauSo;
	while (mauSo == 0) {
		cout << "Mau so phai khac 0. \n Mau so moi la: ";
		cin >> mauSo;
	}
	system("cls");
}
void fraction::print() {
	if (tuSo % mauSo == 0)
		cout << tuSo / mauSo;
	else cout << tuSo << "/" << mauSo << " ";
}
void fraction::simplify() {
	for (int i = tuSo; i >= 1; i--)
		if (tuSo % i == 0 && mauSo % i == 0) {
			tuSo /= i;
			mauSo /= i;
			if ((tuSo < 0 && mauSo < 0) || (tuSo > 0 && mauSo < 0)) {
				tuSo *= -1;
				mauSo *= -1;
			}
			break;
		}
}
fraction fraction::operator+(fraction x) {
	fraction temp;
	temp.tuSo = tuSo * x.mauSo + x.tuSo * mauSo;
	temp.mauSo = x.mauSo * mauSo;
	return temp;
}
fraction fraction::operator-(fraction x) {
	fraction temp;
	temp.tuSo = tuSo * x.mauSo - x.tuSo * mauSo;
	temp.mauSo = x.mauSo * mauSo;
	return temp;
}
fraction fraction::operator*(fraction x) {
	fraction temp;
	temp.tuSo = tuSo * x.tuSo;
	temp.mauSo = x.mauSo * mauSo;
	return temp;
}
fraction fraction::operator/(fraction x) {
	fraction temp;
	temp.tuSo = tuSo * x.mauSo;
	temp.mauSo = x.tuSo * mauSo;
	return temp;
}