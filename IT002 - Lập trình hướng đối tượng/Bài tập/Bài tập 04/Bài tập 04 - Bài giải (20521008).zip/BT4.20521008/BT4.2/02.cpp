#include <iostream>
using namespace std;
class complex {
	double real, imaginary;
public:
	void import();
	void print();
	complex operator+(complex);
	complex operator-(complex);
	complex operator*(complex);
	complex operator/(complex);
};
void total(complex, complex);
void subtract(complex, complex);
void multiply(complex, complex);
void divide(complex, complex);
void main() {
	complex a, b;
	cout << "Nhap so phuc thu nhat:" << endl;
	a.import();
	cout << "Nhap so phuc thu hai:" << endl;
    b.import();
	total(a, b);
	subtract(a, b);
	multiply(a, b);
	divide(a, b);
	system("pause");
}
void total(complex x, complex y) {
	cout << "Tong cua hai so la ";
	complex temp = x + y;
	temp.print();
}
void subtract(complex x, complex y) {
	cout << "Hieu cua hai so la ";
	complex temp = x - y;
	temp.print();
}
void multiply(complex x, complex y) {
	cout << "Tich cua hai so la ";
	complex temp = x * y;
	temp.print();
}
void divide(complex x, complex y) {
	cout << "Thuong cua hai so la ";
	complex temp = x / y;
	temp.print();
}
void complex::import() {
	cout << " Phan thuc: ";
	cin >> real;
	cout << " Phan ao: ";
	cin >> imaginary;
	system("cls");
}
void complex::print() {
	if (imaginary == 0)
		cout << real;
	else if (imaginary < 0) {
		if (real == 0)
			cout << imaginary << "i";
		else if (imaginary == -1)
			cout << real << " -i";
		else cout << real << " - " << -imaginary << "i";
	}
	else {
		if (real == 0)
			cout << imaginary << "i";
		else if (imaginary == 1)
			cout << real << " + i";
		else cout << real << " + " << imaginary << "i";
	}
	cout << endl;
}
complex complex::operator+(complex x) {
	complex temp;
	temp.real = real + x.real;
	temp.imaginary = imaginary + x.imaginary;
	return temp;
}
complex complex::operator-(complex x) {
	complex temp;
	temp.real = real - x.real;
	temp.imaginary = imaginary - x.imaginary;
	return temp;
}
complex complex::operator*(complex x) {
	complex temp;
	temp.real = real * imaginary - x.real * x.imaginary;
	temp.imaginary = real * x.imaginary + x.real * imaginary;
	return temp;
}
complex complex::operator/(complex x) {
	complex temp;
	temp.real = (real * imaginary + x.real * x.imaginary) / (x.real * x.real + x.imaginary * x.imaginary);
	temp.imaginary = (x.real * imaginary - real * x.imaginary) / (x.real * x.real + x.imaginary * x.imaginary);
	return temp;
}