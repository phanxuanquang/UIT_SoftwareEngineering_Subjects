#include <iostream>
using namespace std;

class Matrix {
    int** data;
    int nRows, nCols;
public:
    Matrix();
    Matrix(int r, int c);
    void setAt(int i, int j, int x);
    int getAt(int i, int j);
    void display();
    void resize(int r, int c);
    friend Matrix operator+(const Matrix& m1, const Matrix& m2);
    friend Matrix operator-(const Matrix& m1, const Matrix& m2);
    ~Matrix();
};

void MatrixImport(Matrix&);

int main() {
    Matrix m1, m2, total, multiple;
    cout << "   MA TRAN THU NHAT" << endl;
    MatrixImport(m1);
    cout << "   MA TRAN THU HAI" << endl;
    MatrixImport(m2);
    cout << "   MA TRAN THU NHAT" << endl;
    m1.display();
    cout << "   MA TRAN THU HAI" << endl;
    m2.display();
    total = m1 + m2;
    cout << "   TICH HAI MA TRAN" << endl;
    total.display();
    system("pause");
}

Matrix::Matrix() {
    nRows = nCols = 0;
    data = NULL;
}
Matrix::Matrix(int r, int c) {
    nRows = r;
    nCols = c;
    data = new int* [r];
    for (int i = 0; i < r; i++)
        data[i] = new int[c];
    for (int i = 0; i < nRows; i++)
        for (int j = 0; j < nCols; j++)
            data[i][j] = 0;
}
void Matrix::setAt(int i, int j, int x) {
    data[i][j] = x;
}
int Matrix::getAt(int i, int j) {
    return data[i][j];
}
void Matrix::display() {
    if (nRows == 0) {
        cout << "Khong ton tai ma tran nay" << endl;
        return;
    }
    for (int i = 0; i < nRows; i++) {
        for (int j = 0; j < nCols; j++)
            cout << data[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}
void Matrix::resize(int r, int c) {
    if (data != NULL)
        for (int i = 0; i < nRows; i++)
            delete[] data[i];
    delete[] data;
    nRows = r;
    nCols = c;
    data = new int* [r];
    for (int i = 0; i < r; i++)
        data[i] = new int[c];
    for (int i = 0; i < nRows; i++)
        for (int j = 0; j < nCols; j++)
            data[i][j] = 0;
}
Matrix operator+(const Matrix& m1, const Matrix& m2) {
    if (m1.nCols != m2.nCols || m1.nRows != m2.nRows)
        return Matrix(0, 0);
    Matrix result(m1.nRows, m1.nCols);
    for (int i = 0; i < m1.nRows; i++)
        for (int j = 0; j < m1.nCols; j++)
            result.data[i][j] = m1.data[i][j] + m2.data[i][j];
    return result;
    ;
}
Matrix operator-(const Matrix& m1, const Matrix& m2) {
    if (m1.nCols != m2.nCols || m1.nRows != m2.nRows)
        return Matrix(0, 0);
    Matrix result(m1.nRows, m1.nCols);
    for (int i = 0; i < m1.nRows; i++)
        for (int j = 0; j < m1.nCols; j++)
            result.data[i][j] = m1.data[i][j] - m2.data[i][j];
    return result;
}
Matrix::~Matrix() {
    nRows = nCols = 0;
    data = NULL;
}

void MatrixImport(Matrix& m) {
    int r, l;
    cout << "So hang cua ma tran la: ";
    cin >> r;
    cout << "So cot cua ma tran la: ";
    cin >> l;
    m.resize(r, l);
    system("cls");
    int temp;
    for (int i = 0; i < r; i++)
        for (int j = 0; j < l; j++) {
            cout << "Phan tu tai vi tri (" << i << "," << j << ") la: ";
            cin >> temp;
            m.setAt(i, j, temp);
            system("cls");
        }
}