#include <iostream>
using namespace std;
struct coordinate 
{
    double x;
    double y;
    void SetDiem(coordinate& point, double x = 0, double y = 0) {
        point.x = x;
        point.y = y;
    }
    void print() {
        cout << " (" << x << "," << y << ") ";
    }
};
double distance(coordinate a, coordinate b);
void arrayImport(coordinate arr[], int& size);
void distance_Max(coordinate arr[], int size);
void arrayExport(coordinate arr[], int& size);
void main()
{
    int n;
    cout << "So luong diem la ";
    cin >> n;
    coordinate* array = new coordinate[n];
    arrayImport(array, n);
    arrayExport(array, n);
    distance_Max(array, n);
    system("pause");
}
void arrayImport(coordinate arr[], int& size) {
    cout << endl << "Nhap toa do cac diem: " << endl << endl;
    for (int i = 0; i < size; i++)
    {
        cout << "Diem thu " << i + 1 << ":" << endl;
        {
            int temp = i % 3;
            switch (temp)
            {
            case 0:
                cout << " x = ";
                cin >> arr[i].x;
                cout << " y = ";
                cin >> arr[i].y;
                arr[i].SetDiem(arr[i], arr[i].x, arr[i].y);
                break;
            case 1:
                cout << " x = ";
                cin >> arr[i].x;
                arr[i].SetDiem(arr[i], arr[i].x);
                break;
            default:
                arr[i].SetDiem(arr[i]);
                break;
            }
            cout << endl;
        }
    }
}
void arrayExport(coordinate arr[], int& size) {
    cout << "Cac diem vua nhap la ";
    for (int i = 0; i < size; i++)
        arr[i].print();
    cout << endl << endl;
}
double distance(coordinate a, coordinate b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
};
void distance_Max(coordinate arr[], int size) {
    double max = 0;
    for (int i = 0; i < size - 1; i++)
        for (int j = i + 1; j < size; j++)
            if (distance(arr[i], arr[j]) > max)
                max = distance(arr[i], arr[j]);
    for (int i = 0; i < size - 1; i++)
        for (int j = i + 1; j < size; j++)
            if (distance(arr[i], arr[j]) == max)
            {
                cout << "Hai diem co khoang cach lon nhat co toa do la (" << arr[i].x << "," << arr[i].y << ") va (" << arr[j].x << "," << arr[j].y << ") " << endl;
                return;
            }
}