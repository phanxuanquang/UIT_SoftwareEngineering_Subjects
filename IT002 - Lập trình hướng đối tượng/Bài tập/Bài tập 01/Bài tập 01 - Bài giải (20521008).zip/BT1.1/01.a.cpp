#include <iostream>
using namespace std;
void array_Import(int a[], int x);
void array_Export(int a[], int x);
void arrange(int a[], int x);
void main()
{
    cout << "So phan tu cua mang la ";
    int n;
    cin >> n;
    int* array = new int[n];
    array_Import(array, n);
    arrange(array, n);
    array_Export(array, n);
    system("pause");
}
void array_Import(int a[], int x) {
    cout << endl;
    for (int i = 0; i < x; i++)
    {
        cout << "Phan tu thu " << i + 1 << " la: ";
        cin >> a[i];
    }
    cout << endl;
}
void array_Export(int a[], int x) {
    cout << "Mang sau khi sap xep la: ";
    for (int i = 0; i < x; i++)
        cout << a[i] << " ";
    cout << endl << endl;
}
void arrange(int a[], int x) {
    for (int i = 0; i < x - 1; i++)
        for (int j = i + 1; j < x; j++)
            if (a[i] > a[j]) 
            {
              int temp = a[i];
                  a[i] = a[j];
                  a[j] = temp;
            }
}