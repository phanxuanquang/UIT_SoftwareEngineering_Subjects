#include <iostream>
using namespace std;
struct coordinate {
    double x;
    double y;
    void import() {
        cout << " x = ";
        cin >> x;
        cout << " y = ";
        cin >> y;
        cout << endl;
    }
};
void arrayImport(coordinate arr[], int& size);
double distance(coordinate a, coordinate b);
void distance_Max(coordinate arr[], int size);
void main()
{
    int n;
    cout << "So luong diem la ";
    cin >> n;
    coordinate *array = new coordinate[n];
    arrayImport(array, n);
    distance_Max(array, n);
    system("pause");
}
void arrayImport(coordinate arr[], int& size) {
    cout << endl << "Nhap toa do cac diem: " << endl << endl;
    for (int i = 0; i < size; i++)
    { 
        cout << "Diem thu " << i + 1 << ":" << endl;
        arr[i].import();
    }        
}
double distance(coordinate a, coordinate b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
};
void distance_Max(coordinate arr[], int size) {
    double max = 0;
    for (int i = 0; i < size - 1; i++)
        for (int j = i + 1; j < size; j++)
            if (distance(arr[i], arr[j]) > max)
                max = distance(arr[i], arr[j]);
    for (int i = 0; i < size - 1; i++)
        for (int j = i + 1; j < size; j++)
            if (distance(arr[i], arr[j]) == max)
            {
                cout << "Hai diem co khoang cach lon nhat co toa do (" << arr[i].x << "," << arr[i].y << ") va (" << arr[j].x << "," << arr[j].y << ") " << endl << endl;
                return;
            }
}